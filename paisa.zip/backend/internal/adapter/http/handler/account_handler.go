// Package handler provides HTTP adapters for the application.
package handler

import (
	"context"
	"encoding/json"
	"errors"
	"log/slog"
	"net/http"
	"strings"

	"github.com/go-chi/chi/v5"
	"github.com/go-playground/validator/v10"
	"github.com/google/uuid"
	"github.com/joshu-sajeev/paisa/internal/domain/account"
)

// Limit request body size to 1MB to prevent memory exhaustion (DoS)
const maxBodyBytes = 1_048_576

type AccountService interface {
	Create(ctx context.Context, name string, isPrimary bool, iconKey *string) (*account.Account, error)
	List(ctx context.Context) ([]*account.Account, error)
	Update(ctx context.Context, id uuid.UUID, name *string, iconKey *string, isPrimary *bool, isArchived *bool) error
}

type AccountHandler struct {
	service  AccountService
	validate *validator.Validate
	logger   *slog.Logger
}

func NewAccountHandler(service AccountService, logger *slog.Logger) *AccountHandler {
	return &AccountHandler{
		service:  service,
		validate: validator.New(),
		logger:   logger,
	}
}

type CreateAccountRequest struct {
	Name      string  `json:"name"       validate:"required,max=100"`
	IconKey   *string `json:"icon_key"   validate:"omitempty,min=1,max=50"`
	IsPrimary bool    `json:"is_primary"`
}

type PatchAccountRequest struct {
	Name       *string `json:"name"         validate:"omitempty,min=1,max=100"`
	IconKey    *string `json:"icon_key"     validate:"omitempty,min=1,max=50"`
	IsPrimary  *bool   `json:"is_primary"`
	IsArchived *bool   `json:"is_archived"`
}

func NewAccountResponse(a *account.Account) AccountResponse {
	return AccountResponse{
		ID:         a.ID,
		Name:       a.Name,
		Balance:    a.Balance,
		IconKey:    a.IconKey,
		IsPrimary:  a.IsPrimary,
		IsArchived: a.IsArchived,
		UpdatedAt:  a.UpdatedAt,
	}
}

// Create handles POST /accounts.
func (h *AccountHandler) Create(w http.ResponseWriter, r *http.Request) {
	h.logger.InfoContext(r.Context(), "account create request received")

	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)
	var req CreateAccountRequest

	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()

	if err := decoder.Decode(&req); err != nil {
		h.logger.WarnContext(
			r.Context(),
			"failed to decode account create request body",
			slog.String("error", err.Error()),
		)

		writeErrorJSON(
			w,
			http.StatusBadRequest,
			"INVALID_REQUEST",
			"Request body is invalid or too large",
			"ERR_BAD_REQUEST",
		)
		return
	}

	req.Name = strings.TrimSpace(req.Name)

	if req.IconKey != nil {
		trimmedIconKey := strings.TrimSpace(*req.IconKey)
		req.IconKey = &trimmedIconKey
	}

	if err := h.validate.Struct(req); err != nil {
		h.logger.WarnContext(
			r.Context(),
			"account validation failed",
			slog.String("error", err.Error()),
		)

		var validationErrs validator.ValidationErrors
		if errors.As(err, &validationErrs) {
			for _, fe := range validationErrs {
				if fe.Field() == "IconKey" {
					writeErrorJSON(
						w,
						http.StatusBadRequest,
						"VALIDATION_ERROR",
						"Invalid icon key",
						"ERR_INVALID_ICON_KEY",
					)
					return
				}
			}
		}

		writeErrorJSON(
			w,
			http.StatusBadRequest,
			"VALIDATION_ERROR",
			"Invalid account name",
			"ERR_INVALID_NAME",
		)
		return
	}

	a, err := h.service.Create(r.Context(), req.Name, req.IsPrimary, req.IconKey)
	if err != nil {
		switch {
		case errors.Is(err, account.ErrAccountPrimaryExists):
			h.logger.WarnContext(
				r.Context(),
				"primary account already exists",
				slog.String("name", req.Name),
			)

			writeErrorJSON(
				w,
				http.StatusConflict,
				"CONFLICT",
				"Primary account already exists",
				"ERR_PRIMARY_EXISTS",
			)

		case errors.Is(err, account.ErrAccountNameExists):
			h.logger.WarnContext(
				r.Context(),
				"duplicate account name attempted",
				slog.String("name", req.Name),
			)

			writeErrorJSON(
				w,
				http.StatusConflict,
				"CONFLICT",
				"Account name already exists",
				"ERR_ACCOUNT_EXISTS",
			)

		case errors.Is(err, account.ErrInvalidName):
			h.logger.WarnContext(
				r.Context(),
				"invalid account name from service",
				slog.String("error", err.Error()),
			)

			writeErrorJSON(
				w,
				http.StatusBadRequest,
				"VALIDATION_ERROR",
				"Invalid account name",
				"ERR_INVALID_NAME",
			)

		default:
			h.logger.ErrorContext(
				r.Context(),
				"failed to create account",
				slog.String("error", err.Error()),
			)

			writeErrorJSON(
				w,
				http.StatusInternalServerError,
				"INTERNAL_ERROR",
				"Failed to create account",
				"ERR_INTERNAL_SERVER",
			)
		}

		return
	}

	h.logger.InfoContext(
		r.Context(),
		"account created successfully",
		slog.String("id", a.ID.String()),
	)

	writeJSON(w, http.StatusCreated, NewAccountResponse(a))
}

// List handles GET /accounts.
func (h *AccountHandler) List(w http.ResponseWriter, r *http.Request) {
	accounts, err := h.service.List(r.Context())
	if err != nil {
		h.logger.ErrorContext(
			r.Context(),
			"failed to list accounts",
			slog.String("error", err.Error()),
		)

		writeErrorJSON(
			w,
			http.StatusInternalServerError,
			"INTERNAL_ERROR",
			"Failed to list accounts",
			"ERR_INTERNAL_SERVER",
		)
		return
	}

	response := make([]AccountResponse, 0, len(accounts))

	for _, a := range accounts {
		response = append(response, NewAccountResponse(a))
	}

	writeJSON(w, http.StatusOK, response)
}

// Patch handles PATCH /accounts/{id}.
func (h *AccountHandler) Patch(w http.ResponseWriter, r *http.Request) {
	rawID := chi.URLParam(r, "id")

	id, err := uuid.Parse(rawID)
	if err != nil {
		h.logger.WarnContext(
			r.Context(),
			"invalid account id format in patch",
			slog.String("raw_id", rawID),
		)

		writeErrorJSON(
			w,
			http.StatusBadRequest,
			"INVALID_REQUEST",
			"Invalid account ID format",
			"ERR_INVALID_ID",
		)
		return
	}

	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)
	var req PatchAccountRequest

	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()

	if err := decoder.Decode(&req); err != nil {
		h.logger.WarnContext(
			r.Context(),
			"failed to decode patch body",
			slog.String("error", err.Error()),
		)

		writeErrorJSON(
			w,
			http.StatusBadRequest,
			"INVALID_REQUEST",
			"Request body is invalid or too large",
			"ERR_BAD_REQUEST",
		)
		return
	}

	if req.Name == nil && req.IconKey == nil && req.IsPrimary == nil && req.IsArchived == nil {
		writeErrorJSON(
			w,
			http.StatusBadRequest,
			"VALIDATION_ERROR",
			"At least one field must be provided",
			"ERR_NO_FIELDS",
		)
		return
	}

	if req.Name != nil {
		trimmedName := strings.TrimSpace(*req.Name)
		req.Name = &trimmedName
	}

	if req.IconKey != nil {
		trimmedIconKey := strings.TrimSpace(*req.IconKey)
		req.IconKey = &trimmedIconKey
	}

	if err := h.validate.Struct(req); err != nil {
		h.logger.WarnContext(
			r.Context(),
			"account patch validation failed",
			slog.String("error", err.Error()),
		)

		writeErrorJSON(
			w,
			http.StatusBadRequest,
			"VALIDATION_ERROR",
			"Invalid patch format inputs",
			"ERR_INVALID_INPUT",
		)
		return
	}

	if err := h.service.Update(
		r.Context(),
		id,
		req.Name,
		req.IconKey,
		req.IsPrimary,
		req.IsArchived,
	); err != nil {
		switch {
		case errors.Is(err, account.ErrAccountNotFound):
			writeErrorJSON(
				w,
				http.StatusNotFound,
				"NOT_FOUND",
				"Account not found",
				"ERR_ACCOUNT_NOT_FOUND",
			)

		case errors.Is(err, account.ErrAccountPrimaryExists):
			writeErrorJSON(
				w,
				http.StatusConflict,
				"CONFLICT",
				"Primary account already exists",
				"ERR_PRIMARY_EXISTS",
			)

		case errors.Is(err, account.ErrAccountNameExists):
			writeErrorJSON(
				w,
				http.StatusConflict,
				"CONFLICT",
				"Account name already exists",
				"ERR_ACCOUNT_EXISTS",
			)

		case errors.Is(err, account.ErrInvalidName):
			writeErrorJSON(
				w,
				http.StatusBadRequest,
				"VALIDATION_ERROR",
				"Invalid account name",
				"ERR_INVALID_NAME",
			)

		default:
			h.logger.ErrorContext(
				r.Context(),
				"failed to update account",
				slog.String("id", id.String()),
				slog.String("error", err.Error()),
			)

			writeErrorJSON(
				w,
				http.StatusInternalServerError,
				"INTERNAL_ERROR",
				"Failed to update account",
				"ERR_INTERNAL_SERVER",
			)
		}

		return
	}

	writeJSON(w, http.StatusOK, SuccessResponse{
		Message: "Account updated successfully",
	})
}
